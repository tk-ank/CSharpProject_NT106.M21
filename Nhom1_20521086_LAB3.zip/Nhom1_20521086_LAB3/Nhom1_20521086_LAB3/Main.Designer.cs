﻿namespace Nhom1_20521086_LAB3
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.pnExxercise = new System.Windows.Forms.Panel();
            this.btnBai4 = new System.Windows.Forms.Button();
            this.btnBai3 = new System.Windows.Forms.Button();
            this.btnBai2 = new System.Windows.Forms.Button();
            this.btnBai1 = new System.Windows.Forms.Button();
            this.pnMembers = new System.Windows.Forms.Panel();
            this.LeThanhHang = new System.Windows.Forms.Label();
            this.DinhQuangAn = new System.Windows.Forms.Label();
            this.TranHoTrucAnh = new System.Windows.Forms.Label();
            this.TranChuHungSon = new System.Windows.Forms.Label();
            this.TrangKyAnh = new System.Windows.Forms.Label();
            this.STitle = new System.Windows.Forms.Label();
            this.pnExxercise.SuspendLayout();
            this.pnMembers.SuspendLayout();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.BackColor = System.Drawing.Color.Transparent;
            this.Title.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Title.Location = new System.Drawing.Point(175, 25);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(464, 45);
            this.Title.TabIndex = 0;
            this.Title.Text = "BÀI TẬP THỰC HÀNH BUỔI 3";
            // 
            // pnExxercise
            // 
            this.pnExxercise.BackColor = System.Drawing.Color.Transparent;
            this.pnExxercise.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnExxercise.Controls.Add(this.btnBai4);
            this.pnExxercise.Controls.Add(this.btnBai3);
            this.pnExxercise.Controls.Add(this.btnBai2);
            this.pnExxercise.Controls.Add(this.btnBai1);
            this.pnExxercise.Location = new System.Drawing.Point(25, 100);
            this.pnExxercise.Name = "pnExxercise";
            this.pnExxercise.Size = new System.Drawing.Size(350, 325);
            this.pnExxercise.TabIndex = 1;
            // 
            // btnBai4
            // 
            this.btnBai4.Font = new System.Drawing.Font("Segoe UI Semibold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBai4.Location = new System.Drawing.Point(25, 250);
            this.btnBai4.Name = "btnBai4";
            this.btnBai4.Size = new System.Drawing.Size(300, 50);
            this.btnBai4.TabIndex = 3;
            this.btnBai4.Text = "Bài 4";
            this.btnBai4.UseVisualStyleBackColor = true;
            this.btnBai4.Click += new System.EventHandler(this.btnBai4_Click);
            // 
            // btnBai3
            // 
            this.btnBai3.Font = new System.Drawing.Font("Segoe UI Semibold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBai3.Location = new System.Drawing.Point(25, 175);
            this.btnBai3.Name = "btnBai3";
            this.btnBai3.Size = new System.Drawing.Size(300, 50);
            this.btnBai3.TabIndex = 2;
            this.btnBai3.Text = "Bài 3";
            this.btnBai3.UseVisualStyleBackColor = true;
            this.btnBai3.Click += new System.EventHandler(this.btnBai3_Click);
            // 
            // btnBai2
            // 
            this.btnBai2.Font = new System.Drawing.Font("Segoe UI Semibold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBai2.Location = new System.Drawing.Point(25, 100);
            this.btnBai2.Name = "btnBai2";
            this.btnBai2.Size = new System.Drawing.Size(300, 50);
            this.btnBai2.TabIndex = 1;
            this.btnBai2.Text = "Bài 2";
            this.btnBai2.UseVisualStyleBackColor = true;
            this.btnBai2.Click += new System.EventHandler(this.btnBai2_Click);
            // 
            // btnBai1
            // 
            this.btnBai1.Font = new System.Drawing.Font("Segoe UI Semibold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBai1.Location = new System.Drawing.Point(25, 25);
            this.btnBai1.Name = "btnBai1";
            this.btnBai1.Size = new System.Drawing.Size(300, 50);
            this.btnBai1.TabIndex = 0;
            this.btnBai1.Text = "Bài 1";
            this.btnBai1.UseVisualStyleBackColor = true;
            this.btnBai1.Click += new System.EventHandler(this.btnBai1_Click);
            // 
            // pnMembers
            // 
            this.pnMembers.BackColor = System.Drawing.Color.Transparent;
            this.pnMembers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnMembers.Controls.Add(this.LeThanhHang);
            this.pnMembers.Controls.Add(this.DinhQuangAn);
            this.pnMembers.Controls.Add(this.TranHoTrucAnh);
            this.pnMembers.Controls.Add(this.TranChuHungSon);
            this.pnMembers.Controls.Add(this.TrangKyAnh);
            this.pnMembers.Controls.Add(this.STitle);
            this.pnMembers.Location = new System.Drawing.Point(425, 100);
            this.pnMembers.Name = "pnMembers";
            this.pnMembers.Size = new System.Drawing.Size(350, 325);
            this.pnMembers.TabIndex = 2;
            // 
            // LeThanhHang
            // 
            this.LeThanhHang.AutoSize = true;
            this.LeThanhHang.Location = new System.Drawing.Point(15, 125);
            this.LeThanhHang.Name = "LeThanhHang";
            this.LeThanhHang.Size = new System.Drawing.Size(227, 25);
            this.LeThanhHang.TabIndex = 5;
            this.LeThanhHang.Text = "Lê Thanh Hằng - 20521286";
            // 
            // DinhQuangAn
            // 
            this.DinhQuangAn.AutoSize = true;
            this.DinhQuangAn.Location = new System.Drawing.Point(15, 175);
            this.DinhQuangAn.Name = "DinhQuangAn";
            this.DinhQuangAn.Size = new System.Drawing.Size(232, 25);
            this.DinhQuangAn.TabIndex = 4;
            this.DinhQuangAn.Text = "Đinh Quang Ân - 20520370";
            // 
            // TranHoTrucAnh
            // 
            this.TranHoTrucAnh.AutoSize = true;
            this.TranHoTrucAnh.Location = new System.Drawing.Point(15, 225);
            this.TranHoTrucAnh.Name = "TranHoTrucAnh";
            this.TranHoTrucAnh.Size = new System.Drawing.Size(243, 25);
            this.TranHoTrucAnh.TabIndex = 3;
            this.TranHoTrucAnh.Text = "Trần Hồ Trúc Anh - 20520137";
            // 
            // TranChuHungSon
            // 
            this.TranChuHungSon.AutoSize = true;
            this.TranChuHungSon.Location = new System.Drawing.Point(15, 275);
            this.TranChuHungSon.Name = "TranChuHungSon";
            this.TranChuHungSon.Size = new System.Drawing.Size(262, 25);
            this.TranChuHungSon.TabIndex = 2;
            this.TranChuHungSon.Text = "Trần Chu Hùng Sơn - 20521849";
            // 
            // TrangKyAnh
            // 
            this.TrangKyAnh.AutoSize = true;
            this.TrangKyAnh.Location = new System.Drawing.Point(15, 75);
            this.TrangKyAnh.Name = "TrangKyAnh";
            this.TrangKyAnh.Size = new System.Drawing.Size(212, 25);
            this.TrangKyAnh.TabIndex = 1;
            this.TrangKyAnh.Text = "Trang Kỳ Anh - 20521086";
            // 
            // STitle
            // 
            this.STitle.AutoSize = true;
            this.STitle.Font = new System.Drawing.Font("Segoe UI Semibold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.STitle.Location = new System.Drawing.Point(75, 25);
            this.STitle.Name = "STitle";
            this.STitle.Size = new System.Drawing.Size(219, 30);
            this.STitle.TabIndex = 0;
            this.STitle.Text = "THÀNH VIÊN NHÓM";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Nhom1_20521086_LAB3.Properties.Resources.background_6517956;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnMembers);
            this.Controls.Add(this.pnExxercise);
            this.Controls.Add(this.Title);
            this.Font = new System.Drawing.Font("Segoe UI", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 6, 4, 6);
            this.MaximizeBox = false;
            this.Name = "Main";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bài thực hành 3 - Nhóm 1 - Form điều hướng";
            this.pnExxercise.ResumeLayout(false);
            this.pnMembers.ResumeLayout(false);
            this.pnMembers.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Panel pnExxercise;
        private System.Windows.Forms.Button btnBai1;
        private System.Windows.Forms.Button btnBai2;
        private System.Windows.Forms.Button btnBai4;
        private System.Windows.Forms.Button btnBai3;
        private System.Windows.Forms.Panel pnMembers;
        private System.Windows.Forms.Label STitle;
        private System.Windows.Forms.Label TrangKyAnh;
        private System.Windows.Forms.Label LeThanhHang;
        private System.Windows.Forms.Label DinhQuangAn;
        private System.Windows.Forms.Label TranHoTrucAnh;
        private System.Windows.Forms.Label TranChuHungSon;
    }
}

